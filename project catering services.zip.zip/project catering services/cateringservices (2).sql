-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2024 at 06:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cateringservices`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookdetails`
--

CREATE TABLE `bookdetails` (
  `studentname` varchar(50) NOT NULL,
  `bookid` varchar(50) NOT NULL,
  `customid` varchar(50) NOT NULL,
  `pgid` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookdetails`
--

INSERT INTO `bookdetails` (`studentname`, `bookid`, `customid`, `pgid`, `date`) VALUES
('sneha', '4', '6', '12', '13'),
('Ganga', '4', '105', '7777', '10/08/2024'),
('Rani', '3', '103', '9595', '11/08/2024'),
('Bhargavi', '1', '101', '1234', '12/08/2024');

-- --------------------------------------------------------

--
-- Table structure for table `custdetails`
--

CREATE TABLE `custdetails` (
  `custname` varchar(50) NOT NULL,
  `custid` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobilenumber` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custdetails`
--

INSERT INTO `custdetails` (`custname`, `custid`, `address`, `mobilenumber`) VALUES
('ganesh', '7', 'kailas', '3456878991'),
('shiv', '1', 'nipani', '3764767578'),
('shakti', '1', 'pune', '376476757'),
('bdh', '1', 'nipani', '3764767578'),
('bdh', '1', 'nipani', '3764767578');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `pgid` varchar(50) NOT NULL,
  `custid` varchar(50) NOT NULL,
  `ratings` varchar(50) NOT NULL,
  `comments` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`pgid`, `custid`, `ratings`, `comments`) VALUES
('5576', '7', '657', 'good'),
('12', '13', '9', 'amazing'),
('101', '1', '11', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `guestdetails`
--

CREATE TABLE `guestdetails` (
  `pgid` varchar(50) NOT NULL,
  `custid` varchar(50) NOT NULL,
  `bookid` varchar(50) NOT NULL,
  `mobilenumber` varchar(50) NOT NULL,
  `roomno` varchar(50) NOT NULL,
  `depositamount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guestdetails`
--

INSERT INTO `guestdetails` (`pgid`, `custid`, `bookid`, `mobilenumber`, `roomno`, `depositamount`) VALUES
('1', '2', '3', '568779909', '10', '200000'),
('1', '2', '3', '1234567890', '12', '10000'),
('6', '8', '3', '345687899', '1422', '30,000'),
('9595', '103', '1', '3456878990', '1005', '10000'),
('102', '2', '4', '3456878936', '1002', '5000'),
('11', '365', '12', '5124682378', '2', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `itemid` varchar(50) NOT NULL,
  `itemname` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `cost` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`itemid`, `itemname`, `category`, `cost`) VALUES
('1', '2', 'c', '10');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `type`) VALUES
('user', '1', 'user'),
('chef', '123123', 'chef'),
('admin', '123123', 'admin'),
('staff', '123123', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menuid` varchar(100) NOT NULL,
  `Foodname` varchar(100) NOT NULL,
  `Price` varchar(100) NOT NULL,
  `Availability` varchar(100) NOT NULL,
  `Description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menuid`, `Foodname`, `Price`, `Availability`, `Description`) VALUES
('1', 'ewds', '12', 'wse', 'wqs'),
('101', 'Punjabi thali', '180', 'yes', 'roti,panirthikka,papad,rice'),
('102', 'momos', '80', 'yes', 'variety of momos  available'),
('103', 'puribhaji', '60', 'yes', 'normal puri,palak puri available');

-- --------------------------------------------------------

--
-- Table structure for table `paymentdetails`
--

CREATE TABLE `paymentdetails` (
  `custid` varchar(50) NOT NULL,
  `guestid` varchar(50) NOT NULL,
  `roomno` varchar(50) NOT NULL,
  `payamount` varchar(50) NOT NULL,
  `paydate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymentdetails`
--

INSERT INTO `paymentdetails` (`custid`, `guestid`, `roomno`, `payamount`, `paydate`) VALUES
('3', '66', '1722', '30000', '2'),
('11', '2', '28', '30000', '12'),
('101', '1', '1001', '30000', '15/08/2024'),
('102', '3', '1002', '35000', '21/08/2024'),
('103', '4', '1003', '30000', '22/08/2024');

-- --------------------------------------------------------

--
-- Table structure for table `pgdetails`
--

CREATE TABLE `pgdetails` (
  `pgid` varchar(50) NOT NULL,
  `pgname` varchar(50) NOT NULL,
  `pglocation` varchar(50) NOT NULL,
  `contactdetails` varchar(50) NOT NULL,
  `roomno` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pgdetails`
--

INSERT INTO `pgdetails` (`pgid`, `pgname`, `pglocation`, `contactdetails`, `roomno`) VALUES
('1', 'bhargu', 'nipani', '34876632456', '28'),
('8878', 'rani', 'pune', '46880903', '2217'),
('101', 'shivsakti', 'Nipani', '2653764736', '102'),
('104', 'RAM', 'Belagavi', '7648357676', '5006'),
('1005', 'Metro', 'mumbai', '3776847587', '5018');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`name`, `address`, `phonenumber`) VALUES
('dsfgh', 'dfghj', '12345'),
('Bhargavi', 'Nipani', '2465768845'),
('Rani', 'belagavi', '6784799770'),
('Ekta', 'pune', '3746878676'),
('Ganga', 'mumbai', '5687538734'),
('anand sonar', 'snk', '895107405');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
